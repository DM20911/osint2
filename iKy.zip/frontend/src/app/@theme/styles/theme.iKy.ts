import { NbJSThemeOptions, COSMIC_THEME as baseTheme } from '@nebular/theme';

const baseThemeVariables = baseTheme.variables;

export const IKY_THEME = {
  name: 'iKy',
  base: 'iKy',
  variables: {
  },
} as NbJSThemeOptions;
