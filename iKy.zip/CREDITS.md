# CREDITS

Turn on the tool and see the drop-down called ***Contributors***, ***Proyects***, ***People*** and ***Friends***

# CONTRIBUTORS

Thanks goes to these people

## Sebastián Leonardo Kennedy
Code, review, vagrant.
<div><img alt="Gitlab" src="https://img.shields.io/badge/Gitlab-@skennedy-red.svg?style=social&logo=gitlab"></div>
<div><img alt="Twitter" src="https://img.shields.io/badge/Twitter-@emips_sk-red.svg?style=social&logo=twitter"></div>
## Juan Diego Ianelli
Review, translate and corrections
<div><img alt="Gitlab" src="https://img.shields.io/badge/Gitlab-@jiannelli-red.svg?style=social&logo=gitlab"></div>
## Sebastián Ariel Bevacqua
Code (Ghostproject), upgrade dependencies
<div><img alt="Gitlab" src="https://img.shields.io/badge/Gitlab-@sebabeva-red.svg?style=social&logo=gitlab"></div>
<div><img alt="Twitter" src="https://img.shields.io/badge/Twitter-@sebabeva-red.svg?style=social&logo=twitter"></div>
<div><img alt="Linkedin" src="https://img.shields.io/badge/Linkedin-@sebabeva-red.svg?style=social&logo=linkedin"></div>
## Marcos Miguel García
Docker
<div><img alt="Gitlab" src="https://img.shields.io/badge/Gitlab-@marcositu-red.svg?style=social&logo=gitlab"></div>
<div><img alt="Twitter" src="https://img.shields.io/badge/Twitter-@artsweb-red.svg?style=social&logo=twitter"></div>
<div><img alt="Linkedin" src="https://img.shields.io/badge/Linkedin-@marcosmiguelgarcia-red.svg?style=social&logo=linkedin"></div>
<div><img alt="Web" src="https://img.shields.io/badge/web-https%3A%2F%2Fwww.artssec.com-informational.svg"></div>
## physics-sp
Review and corrections of documentation
<div><img alt="Gitlab" src="https://img.shields.io/badge/Gitlab-@physics--sp-red.svg?style=social&logo=gitlab"></div>
